# Tetris

Tetris game for Android

<img src="images/game_start.png" width="200">.  <img src="images/game_play.gif" width="200">.  <img src="images/game_over1.png" width="200">


# Build
```bash
 ./gradlew assembleDebug
```
